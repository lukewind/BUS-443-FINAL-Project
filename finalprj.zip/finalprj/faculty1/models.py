from django.db import models

# Create your models here.


class Studentdetails(models.Model):
    studentid = models.IntegerField()
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.CharField(max_length=500)
    year = models.CharField(max_length=500)
    GPA = models.FloatField()

class Coursedetails(models.Model):
    courseid = models.IntegerField(default=12345)
    coursetitle = models.CharField(max_length=500)
    coursename = models.CharField(max_length=500)
    coursesection = models.IntegerField()
    coursedepartment = models.CharField(max_length=500)
    courseinstructor = models.CharField(max_length=500)

class Studentenrollment(models.Model):
    studentid = models.IntegerField()
    coursename = models.CharField(max_length=500)
