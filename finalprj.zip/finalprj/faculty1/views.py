from django.shortcuts import render
from django.http import HttpResponse
from faculty1.models import Studentdetails,Coursedetails, Studentenrollment
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.db import connection

# Create your views here.

@login_required
def home(request):
    cursorobj = connection.cursor()
    cursorobj.execute("select count(*) from faculty1_studentenrollment")
    gpadata = cursorobj.fetchone()
    #gpadata()
    #print(gpadata)
    num = gpadata[0]
    cursorobj.execute("select count(coursetitle) from faculty1_coursedetails;")
    courses = cursorobj.fetchone()
    #print(courses)
    num1 = courses[0]
    cursorobj.execute("SELECT AVG(gpa) FROM faculty1_studentdetails;")
    gpa = cursorobj.fetchone()
    #print(courses)
    num2 = gpa[0]
    cursorobj.execute("SELECT count(year) FROM faculty1_studentdetails WHERE year = 'Senior';")
    seniors = cursorobj.fetchone()
    #print(courses)
    num3 = seniors[0]
    cursorobj.execute("SELECT count(year) FROM faculty1_studentdetails WHERE year = 'Junior';")
    juniors = cursorobj.fetchone()
    #print(courses)
    num4 = juniors[0]
    cursorobj.execute("SELECT count(year) FROM faculty1_studentdetails WHERE year = 'Sophomore';")
    sophomore = cursorobj.fetchone()
    #print(courses)
    num5 = sophomore[0]
    context = {'name':'Final Project by Luke Windley', 'data':num, 'courses': num1, 'gpa': num2, 'seniors':num3, 'juniors':num4, 'sophomore':num5}
    return render(request, 'faculty1/home.html', context)

@login_required
def studentdetails(request):
    studentdata = Studentdetails.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'studentdata':minidata}
    return render(request, 'faculty1/studentdetails.html', context)

@login_required
def coursedetails(request):
    coursedata = Coursedetails.objects.all()
    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    minidata1 = paginator.get_page(page)
    context = {'coursedata':minidata1}
    return render(request, 'faculty1/coursedetails.html', context)

@login_required
def studentenrollment(request):
    studentdata = Studentdetails.objects.all()
    coursedata = Coursedetails.objects.all()
    if 'studentid' in request.session:
        enrollmentdata = Studentenrollment.objects.filter(studentid = request.session['studentid'])
    else:
        enrollmentdata = Studentenrollment.objects.all()
    context = {'student':studentdata, 'course':coursedata, 'enrollment':enrollmentdata}
    return render(request, 'faculty1/studentenrollment.html', context)

def saveenroll(request):
    if ('student' in request.GET and 'class' not in request.GET):
        request.session['studentid'] = request.GET.get('student')
        print(request.session['studentid'])

    if('student' and 'class' in request.GET):
        student = request.GET.get('student')
        classname = request.GET.get('class')
        dataobj = Studentenrollment(studentid = student, coursename = classname)
        #should check here if that student has enrolled in that course / make sure they're not enrolling in no more than 3 courses
        #i ran through many iterations attempting to make it so Students couldn't enroll in the same course or more than 3
        #all the online help and resources i tried to reference were unable to make it so i could do this
        #i went ahead and removed the failed attempts and imported files as they seemed unnecessary if they didn't work
        dataobj.save()
    return HttpResponse("Success")

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
