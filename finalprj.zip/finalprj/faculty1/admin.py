from django.contrib import admin
from faculty1.models import Studentdetails, Coursedetails

# Register your models here.


admin.site.register(Studentdetails)

admin.site.register(Coursedetails)
